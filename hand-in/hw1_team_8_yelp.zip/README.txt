===================TEAM 8===================

This ZIP file contains the following files:
1. hw1_team_8_yelp.pdf - A document answering all
   of the required questions for home work 1.
2. team_8_notebook.ipynb - A Jupyter notebook used
   to create the DB, DW, required views and their respective
   outputs.
   Please execute each cell in this file in their order of appearance
   in order to ensure a smooth run.
   ALSO NOTE - You'll need to change the credentials at the
   beginning of the file to match your local DB's.
3. small_business_data_by_state_usa_2017.csv - A CSV which
    contains the the required data for our business questions
    regardin the volume of activity on a state level.

========Almog Asraf, Daniel Pidtylok, Nir Levanon========